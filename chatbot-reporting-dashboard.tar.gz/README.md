
  # Chatbot Reporting Dashboard

  This is a code bundle for Chatbot Reporting Dashboard. The original project is available at https://www.figma.com/design/lxuOCZECsyIvHhUEh6Ut9e/Chatbot-Reporting-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  